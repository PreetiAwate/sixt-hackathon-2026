# SIXT + TUM / Project 5 - event rules

This package is held locally until Ioannis Tzachristas explicitly authorizes its stage release.
The organizers will announce release times, submission cutoffs and the collection channel.

Submit `Project_5/public_answers.csv` at the Stage 1 cutoff and `Project_5/final_answers.csv`
at the final cutoff, each with exactly `question_id,answer`. Use the matching stage's data.
Stage 1 answers are locked before Stage 2 is released. Each stage has 200 scored questions;
every question has equal weight within that stage. Wrong, blank or missing answers score zero.
Malformed submissions and duplicate/unknown IDs are rejected; follow the announced handling policy.

Numbers accept absolute error <=0.01 unless an exact integer is requested. Counts must be exact.
Round monetary answers only at the final requested step. Follow dates, text and N/A conventions
in business_rules.md. The format checker checks structure only, never answer correctness.

## Grade

P = Stage 1 accuracy in percent; F = Stage 2 accuracy in percent.
Dataset score D = 0.35 P + 0.65 F. Dataset grade contribution = 0.65 D (maximum 65 points).
The other 35 points come from the event criteria below, scaled by 35/75:

| Criterion | Raw maximum |
|---|---:|
| Problem understanding | 15 |
| Quality of approach | 25 |
| Business relevance and reusability | 15 |
| Code quality and reproducibility | 10 |
| Presentation and demo | 10 |

### Small-model bonus: 40 points

A verified qualifying small-model workflow earns 40 additional points, for a maximum of 140.
Every generative model used for code/methods, answers or validation, including fallbacks,
must have at most 40 billion total parameters. Count all MoE experts; quantization does not
reduce parameter count. Qualifying models must do substantive work. Supply model IDs,
parameter-count evidence and usage logs. Unknown sizes cannot establish bonus eligibility.
Larger models remain eligible for the 100 base points. Do not add the general event +5 bonus.
This special policy applies only to the SIXT + TUM challenge; other projects keep their own rules.

## Method and report

Submit method code, dependencies, a completed report, model-use declaration and demo/slides.
Explain how results were calculated and checked. The judged deliverable is the answer CSV;
there is no hidden execution of a frozen submitted program.
Use the provided report template and cite dataset version 7.0.0 and the package hash.
After coordinating content, authorship and timing with the organizers, upload the report
manuscript to arXiv to finalize the submission; report upload does not reopen answer cutoffs.
Do not publish datasets, question files, reference answers or organizer material in reports
or attachments. Contact the organizers if an arXiv submission cannot be completed.

Contact: Ioannis Tzachristas, ioannis.tzachristas@tum.de
LinkedIn: https://www.linkedin.com/in/ioannis-tzachristas-83a00522a/

Policy version: `problem7-65-35-plus40-v2`. Event content revision: `p5-local-v4-bonus40`.
