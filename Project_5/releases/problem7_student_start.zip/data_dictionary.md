# Version 7 data dictionary

## Coupled fulfilment tables

All case_id and job_id references are exact joins. Rows have no implicit order.

| File | Row meaning and key | Fields |
|---|---|---|
| hard_opt_cases.csv | One independent scenario; case_id | day_origin is the calendar origin for integer day offsets; notes describes the synthetic scope. |
| hard_opt_jobs.csv | One indivisible job; case_id + job_id | product_id; quantity > 0; ready_day; due_day; last_day; late_penalty_cents_per_unit_day; unfilled_penalty_cents (total job penalty). |
| hard_opt_options.csv | One proposed alternative; case_id + option_id | job_id; warehouse_region; supplier_id; dispatch_day; variable_cost_cents (total for this option, not a unit price). |
| hard_opt_stock.csv | Fixed stock pool; case_id + warehouse_region + product_id | available_units, a nonnegative integer. |
| hard_opt_dispatch.csv | Shared daily unit capacity; case_id + warehouse_region + dispatch_day | capacity_units, a nonnegative integer. |
| hard_opt_suppliers.csv | Scenario supplier conditions; case_id + supplier_id | lead_days >= 0; activation_cost_cents; minimum_units; maximum_units; active (1 or 0). Minimum applies only if used. |
| hard_opt_changes.csv | Counterfactual field override; case_id + change_id | table_name; target selector columns; field; new_value. Allowed fields: stock.available_units, dispatch.capacity_units, suppliers.active/lead_days/activation_cost_cents/minimum_units/maximum_units. Empty target columns are unused. |

All costs are euro cents; no FX conversion applies. Day offsets and capacity
units are integers. Different cases never share stock, capacity, jobs or fees.


## Flow simulation CSV columns

- `flow_cases.csv`: one row per scenario. `horizon_step` is the inclusive action
  cutoff; `knowledge_cutoff_step` is the inclusive recorded-version cutoff.
  `first_*` and optional `second_*` define the stated what-if; an empty second
  event/action means no second intervention. Steps are integer logical times,
  not dates, and are comparable only within their case.
- `flow_stock.csv`: unique (case_id,product_id,warehouse) opening free units.
- `flow_orders.csv`: unique order_id within a case, linked customer/product and
  warehouse, release and deadline steps, requested units, and explicit integer
  EUR-cent price, cost, late/unfilled penalties, cancellation and return fees.
- `flow_events.csv`: versioned action rows. event_type is RECEIPT, CANCEL,
  RETURN or DISPATCH. Product/warehouse are used for receipts; warehouse alone
  for dispatches; order_id for cancellation/return. Empty unused identifiers
  carry no meaning. units is a nonnegative integer; restock is true/false;
  status is posted/void. recorded_step is observation time, effective_step is
  action time; version_id is a lexical tie-break only.
- `flow_contracts.csv`: versioned customer terms per case. priority is an integer
  (smaller means earlier); rebate_threshold_units and rebate_per_unit_cents
  determine the end-of-case rebate; status is active/inactive. recorded_step and
  version_id select the known version exactly as for events.


## Retained 25-table schema

# Data Dictionary — Initial Release

The initial release uses relatively clear column names. The final release will use the same business entities but with schema/column-name drift.

## Core tables

### accounts.csv
- `account_id`: account identifier
- `account_name`: account display name
- `segment`: SMB, Mid-Market, Enterprise, or Public Sector
- `industry`: account industry
- `account_country`, `account_region`: account geography
- `account_manager`: owner of account
- `account_start_date`: account start date
- `is_test_account`: whether this is a test account

### customers.csv
- `customer_id`: raw customer record identifier
- `account_id`: linked account
- `email`: raw email used for identity resolution
- `country`, `region`: customer geography
- `acquisition_channel`: acquisition channel
- `signup_date`, `trial_start_date`
- `is_test_customer`: whether this is a test customer

### orders.csv
- `order_id`, `customer_id`, `order_date`
- `order_status`: completed, shipped, cancelled, pending
- `payment_status`: paid, failed, pending
- `currency`
- `coupon_code`
- `order_level_discount_native`
- `fraud_flag`
- `is_duplicate`
- `duplicate_of_order_id`
- `source_channel`

### order_items.csv
- `order_item_id`, `order_id`, `product_id`
- `quantity`, `unit_price_native`, `line_discount_native`

### payments.csv
- `payment_id`, `order_id`, `payment_date`
- `payment_status_detail`: settled, authorized, failed, pending
- `currency`, `payment_amount_native`

### refunds.csv
- `refund_id`, `order_id`, `product_id`
- `refund_date`, `currency`, `refund_amount_native`
- `refund_status`: approved, pending, rejected
- `refund_reason`

### products.csv
- `product_id`, `product_name`, `initial_category`, `family`
- `list_price_eur`, `standard_cost`, `cost_currency`
- `launch_date`

### product_category_history.csv
- `product_id`, `category`, `valid_from`, `valid_to`

### shipments.csv
- `shipment_id`, `order_id`, `carrier`
- `shipped_at`, `promised_delivery_date`, `delivered_at`
- `warehouse_region`
- `shipping_cost_native`, `currency`

### support_tickets.csv
- `ticket_id`, `customer_id`, `related_order_id`
- `opened_at`, `resolved_at`
- `issue_type`, `priority`, `ticket_status`
- `support_channel`, `sentiment_score`, `escalated`

### marketing_touches.csv
- `touch_id`, `customer_id`, `touch_date`
- `marketing_channel`, `campaign`
- `currency`, `cost_native`

### fx_rates.csv
- `month`, `currency`, `eur_rate`

### sales_targets.csv
- `month`, `country`, `region`, `net_revenue_target_eur`

## Additional tables and stocktake anchors

### web_sessions.csv
Used only by web-session conversion questions.
- `session_id`, `customer_id`, `session_date`, `traffic_source`, `page_views`, `minutes_on_site`

### employee_regions.csv
Mostly distractor.
- `account_manager`, `region`, `team_size`, `capacity_band`

### warehouse_inventory.csv
Required opening stocktake anchors for V6 inventory reconciliation, valuation, reorder and recorded-demand questions.
- `product_id`, `warehouse_region`, `on_hand_units`, `last_stocktake_date`

### promotions.csv
Mostly distractor.
- `campaign`, `category`, `promo_start`, `promo_end`, `planned_budget_eur`


## V6 added business tables

The eight new tables retain the same column names in both stages. The inherited final-stage aliases above remain in use. Exact semantics and key constraints are in business_rules.md.

### suppliers.csv

`supplier_id`, `supplier_name`, `country`, `contract_start`, `contract_end`, `is_test_supplier`.

### purchase_order_lines.csv

`po_line_id`, `supplier_id`, `product_id`, `warehouse_region`, `ordered_at`, `promised_at`, `ordered_units`, `unit_cost_native`, `currency`, `status`.

### goods_receipts.csv

`receipt_id`, `po_line_id`, `received_at`, `accepted_units`, `rejected_units`, `status`.

### inventory_movements.csv

`movement_id`, `product_id`, `warehouse_region`, `event_at`, `movement_type`, `units_delta`, `source_id`, `status`.

### stock_policies.csv

`product_id`, `warehouse_region`, `valid_from`, `valid_to`, `reorder_point`, `target_units`.

### return_inspections.csv

`inspection_id`, `refund_id`, `warehouse_region`, `inspected_at`, `units_received`, `restockable_units`, `recovery_unit_value_eur`, `disposition`, `status`.

### support_worklogs.csv

`worklog_id`, `ticket_id`, `worked_at`, `minutes_worked`, `hourly_rate_native`, `currency`, `work_status`, `is_billable`.

### account_contract_versions.csv

`contract_id`, `account_id`, `revision`, `recorded_at`, `valid_from`, `valid_to`, `status`, `service_credit_eur`, `quarterly_fee_eur`, `included_support_minutes`.
