# SIXT + TUM / Project 5 - initial stage

Local release candidate 7.0.0 (p5-local-v3-hard-quarter). Do not distribute until Ioannis authorizes this stage.

Calculate all 200 answers from the 37 CSV tables in `datasets/`. Questions 001-150 retain the established company calculations. Questions 151-180 add constrained allocation and counterfactual optimization; 181-200 add chronological event simulation and counterfactual replay. Read the explicit rules; all outputs are scalar CSV values.

Fill `public_answers.csv` with exactly `question_id,answer`. Use `public_leaderboard_questions.csv` and this stage's data. Both stages are independent snapshots. Reusing methods is allowed.

[Business rules](business_rules.md) | [Column dictionary](data_dictionary.md) | [Hard-task rules](HARD_TASK_RULES.md) | [Event grading and submissions](EVENT_RULES.md)

The ten unscored practice questions and answer values are in `solved_examples.csv`; they use this initial snapshot. Detailed explanations and all scored keys remain private.

The format checker validates CSV structure, not answer correctness. Use the method/model declarations and LaTeX report template when submitting your work. See EVENT_RULES.md for the coordinated arXiv follow-up.
