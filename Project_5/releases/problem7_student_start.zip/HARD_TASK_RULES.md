# Version 7 calculation rules - initial

Questions 001-150 retain the earlier metric definitions below, including the raw-customer acquisition-channel clarification. Questions 151-180 use only the hard_opt_* scenario tables and their rules; questions 181-200 use only the flow_* scenario tables and their rules. Scenario identities link to the company snapshot for context. Do not apply inherited customer exclusion, FX, reference-time or aggregation rules to scenario tables unless the scenario rules explicitly require it. All scenario money is in integer EUR cents.

For earliest-valid-order-date-by-acquisition-channel questions, use the raw customer linked directly to the order, not its canonical resolved customer.

The event grade is defined in EVENT_RULES.md; stages are released only on explicit organizer instruction.

## Coupled fulfilment decision cases (hard_opt_*.csv)

These are separate synthetic decision scenarios. A case's stock, capacities,
costs and supplier conditions are given only by its `hard_opt_*` rows. Product,
warehouse and supplier identifiers refer to the supplied catalog identities;
do not import operational balances, FX, contract dates, order-validity rules or
costs from other datasets into these cases. All monetary inputs are integer
euro cents. Day numbers are integer offsets from the case's day_origin.

For each case, independently choose either one listed fulfilment option for a
job or leave that whole job unfilled. Splitting a job or using two options for
it is forbidden. Options that fail any condition below cannot be chosen.

1. An option dispatches the job's entire quantity from its named warehouse.
   Dispatch must be on or after the job's ready_day. Arrival is dispatch_day
   plus that option's supplier lead_days. Arrival must be on or before last_day.
   The supplier must have active=1. Equality at either boundary is allowed.
2. Selected quantities cannot exceed available_units for any warehouse/product
   pair or capacity_units for any warehouse/dispatch-day pair. Stock is a fixed
   case-wide pool; there is no replenishment and no carry-over between cases.
   Dispatch capacity counts units, not jobs. A supplier's assignment quantity
   sums all selected job quantities across warehouses and days.
3. Each used supplier must receive at least minimum_units and at most maximum_units.
   An unused supplier receives zero and incurs no activation cost. A used
   supplier incurs activation_cost_cents exactly once per case. Supplier fees
   are not charged once per option, warehouse or day.
4. A selected option costs variable_cost_cents in total for the whole job,
   plus quantity * late_penalty_cents_per_unit_day * max(0, arrival_day-due_day).
   Do not multiply variable_cost_cents by quantity. An unfilled job incurs its
   unfilled_penalty_cents once, and no variable, late or supplier-activation
   cost on its own. An active supplier is not automatically a used supplier.
5. Minimize the sum of option costs, lateness costs, activation costs and
   unfilled-job penalties. The all-unfilled plan is feasible. No requirement
   to fulfil a fixed number of jobs or exhaust capacity is implied.
6. The counterfactual applies every row in hard_opt_changes.csv for that case
   simultaneously as an exact field replacement, then reoptimizes all choices
   from scratch. A stock change targets warehouse_region + product_id; a
   dispatch change targets warehouse_region + dispatch_day; a supplier change
   targets supplier_id. Blank selector columns are not wildcard matches.
   table_name is stock, dispatch or suppliers. No target/field occurs twice.
   Other fields remain unchanged. Baseline questions ignore all change rows.
7. Cost change means (minimum counterfactual cost - minimum baseline cost).
   It may be negative. Divide integer cents by 100 once at the end and return
   EUR with two decimal places. Multiple optimal plans are allowed because
   their minimum cost is identical. No particular plan is required in the CSV.

Proposed options intentionally include some unavailable or too-late alternatives;
apply the stated rules before optimizing. These rules fully define both stages.


## Stateful fulfilment simulations (flow_* tables)

These cases are separate synthetic operational scenarios. Product, warehouse and
customer keys refer to identities in the stage's existing tables. Use only the
five flow_* tables to calculate a flow case: do not add the original orders,
payments, inventory, contracts or business exclusions to these simulations.
Each case starts independently with its listed opening stock and no orders in
progress. All money is integer EUR cents; return the final monetary answer in
EUR with two decimal places. No tax, FX conversion or unstated costs apply.

**Known versions.** For each (case_id,event_id), retain versions whose
recorded_step <= knowledge_cutoff_step, then select the greatest
(recorded_step,version_id), comparing version_id lexicographically. Select before
checking status or effective_step. A selected void version removes that event;
otherwise use it only when effective_step <= horizon_step. Apply the same known
version selection to (case_id,customer_id) in flow_contracts. A selected inactive
contract gives priority 99 and no rebate. Contract terms apply throughout the
case; they are not a second time series of actions. Physical CSV row order and
the numerical appearance of version IDs do not establish precedence.

**Event order.** An order releases at release_step. Combine these releases with
the selected events and process ascending effective_step, then action priority
CANCEL, RETURN, RECEIPT, RELEASE, DISPATCH, then lexical event_id (order_id for a
release). Releases after the horizon are not processed. At the horizon, finish
all actions at that step before calculating the result. A deadline is met when
a dispatch occurs at or before deadline_step.

**Reservations.** At release, the order's requested units join its one product
and warehouse queue. After every action, allocate free stock to released,
uncancelled, unshipped, unreserved units in ascending (contract priority,
deadline_step,release_step,order_id). Partial reservations are allowed. Existing
reservations are sticky: a later higher-priority order cannot take them. Within
an order, units have sequence numbers 1..units. Reserve and dispatch the lowest
available sequence numbers first. Reservations remove units from free stock.

**RECEIPT** adds its units to free stock for the listed product/warehouse.
**CANCEL** cancels up to its units of the referenced order's currently released,
uncancelled, unshipped units, lowest unit sequence first, whether reserved or
not. Freed reservations return to free stock. Requested units that cannot be
cancelled are ignored. Each actually cancelled unit earns cancellation_fee_cents.
**DISPATCH** provides a one-use warehouse capacity of units across all products.
Among that warehouse's orders with reservations, dispatch in the same queue
order, up to capacity, including partial orders. Unused capacity expires.
There is no automatic shipment at another time.
**RETURN** returns up to its units of the referenced order's already dispatched,
not-yet-returned units, latest dispatch first and highest sequence first within
a dispatch. A return for an unshipped unit has no effect. Every actual return
refunds the full unit price and incurs return_fee_cents. If restock is true it
also adds one unit to free stock and recovers unit_cost_cents; otherwise neither
stock nor cost is recovered. Prior late penalties are never reversed.

**Net contribution.** Sum retained sales revenue, subtract cost of every
dispatched unit, add cost recovered on restocked returns, subtract late penalties
for every unit dispatched strictly after its deadline, subtract unfilled
penalties for released units still neither dispatched nor cancelled at the
horizon, add cancellation fees and subtract return fees. Returned units do not
become unfilled orders. For each customer, count retained (dispatched minus
returned) units across all its orders in this case. If that count is at least
rebate_threshold_units, subtract rebate_per_unit_cents for *every* retained
unit of that customer, not only units above the threshold.

**Declared what-if.** First select known event versions exactly as above. Apply
first_action, then second_action when present, to the indicated selected event:
SHIFT adds the integer value to effective_step; SET_UNITS replaces units with
the integer value. Event IDs, known versions and all other facts stay fixed.
Reapply the horizon filter after edits, and replay from the original opening
state. The second edit does not start from the baseline's closing state. A
question asking for a change means what-if contribution minus baseline
contribution, signed. No scenario edits apply to baseline questions.
